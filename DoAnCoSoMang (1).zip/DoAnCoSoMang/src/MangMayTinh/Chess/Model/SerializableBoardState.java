package MangMayTinh.Chess.Model;

import java.awt.Point;
import java.io.Serializable;
import java.util.List;

public class SerializableBoardState implements Serializable {
    private static final long serialVersionUID = 1L;

    public static class SerializablePiece implements Serializable {
        private static final long serialVersionUID = 1L;
        public String className;
        public Point position;
        public boolean isFirstPlayerPiece;
        
        public SerializablePiece(String className, Point position, boolean isFirstPlayerPiece) {
            this.className = className;
            // Create a new Point to ensure it's properly serialized
            this.position = new Point(position);
            this.isFirstPlayerPiece = isFirstPlayerPiece;
        }
        
        @Override
        public String toString() {
            return className + " at " + position.x + "," + position.y + " (" + (isFirstPlayerPiece ? "P1" : "P2") + ")";
        }
    }

    public final List<SerializablePiece> pieces;
    public final int currentTurn; // 1 or 2
    public final boolean forFirstPlayer; // Indicates which player perspective this state is for

    public SerializableBoardState(List<SerializablePiece> pieces, int currentTurn, boolean forFirstPlayer) {
        this.pieces = pieces;
        this.currentTurn = currentTurn;
        this.forFirstPlayer = forFirstPlayer;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("BoardState: turn=" + currentTurn + 
                                           ", forPlayer=" + (forFirstPlayer ? "P1" : "P2") + 
                                           ", pieces=" + pieces.size() + "\n");
        for (SerializablePiece piece : pieces) {
            sb.append("  ").append(piece).append("\n");
        }
        return sb.toString();
    }
}
