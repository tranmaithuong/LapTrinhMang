/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MangMayTinh.Chess.Connection.Server;

import MangMayTinh.Chess.Model.Enum.MessageType;
import java.awt.Color;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author thinhle
 */
public class Server extends javax.swing.JFrame {
    ArrayList<Player> waiting = new ArrayList<>();
    List<Match> ongoing = new ArrayList<>();
    Thread listener;
    ObjectOutputStream sender = null;
    ObjectInputStream receiver = null;
    
    /**
     * Creates new form Server
     */
    public Server() {
        initComponents();
        InetAddress inetAddress = this.getInetAddress();
        this.ipAddressLabel.setText(inetAddress.getHostAddress());
        this.getRootPane().setDefaultButton(startServerButton);
    }
    
    private void startServer(int port) {
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            this.listener = new Thread(() -> {
                while (true) {
                    try {
                        System.out.println("Waiting for client connections...");
                        Socket socket = serverSocket.accept();
                        System.out.println("Client connected from: " + socket.getInetAddress().getHostAddress());
                        
                        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                        
                        // Read initial message
                        MessageType type = (MessageType) in.readObject();
                        String name = (String) in.readObject();
                        System.out.println("Received initial request: " + type + " from " + name);
                        
                        if (type == MessageType.RECONNECT_REQUEST) {
                            handleReconnectRequest(socket, out, in, name);
                        } else if (type == MessageType.name) {
                            handleNewConnection(socket, out, in, name);
                        } else {
                            // Unknown initial message
                            out.writeObject(MessageType.string);
                            out.writeObject("Invalid initial request");
                            socket.close();
                        }
                        
                        // Clean up finished matches periodically
                        cleanupFinishedMatches();
                    } catch (Exception ex) {
                        System.out.println("Error handling client connection: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }
            });
            this.listener.start();
            this.messageLabel.setText("Server started on port " + port);
        } catch (IOException ex) {
            this.messageLabel.setText("Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    private void handleReconnectRequest(Socket socket, ObjectOutputStream out, ObjectInputStream in, String name) {
        System.out.println("Processing reconnect request from: " + name);
        System.out.println("Current matches: " + ongoing.size());
        
        boolean reconnected = false;
        boolean gameEnded = false;
        
        synchronized(ongoing) {
            for (Match match : ongoing) {
                boolean canReconnectAsFirst = name.equals(match.firstPlayerName) && !match.firstConnected;
                boolean canReconnectAsSecond = name.equals(match.secondPlayerName) && !match.secondConnected;
                boolean isPlayerInMatch = name.equals(match.firstPlayerName) || name.equals(match.secondPlayerName);
                
                // If player was in a match but the match has ended, notify them
                if (isPlayerInMatch && !match.isRunning) {
                    gameEnded = true;
                    continue;
                }
                
                if (canReconnectAsFirst || canReconnectAsSecond) {
                    System.out.println("Found match for " + name + " to reconnect");
                    Player reconnectingPlayer = new Player(socket, out, in);
                    reconnectingPlayer.playerName = name;
                    match.attemptReconnect(reconnectingPlayer, name);
                    reconnected = true;
                    break;
                }
            }
        }
        
        if (!reconnected) {
            try {
                String message = gameEnded 
                    ? "Your game has ended. Please start a new game."
                    : "No active game found for " + name;
                    
                out.writeObject(MessageType.RECONNECT_FAILED);
                out.writeObject(message);
                socket.close();
                
                System.out.println("Reconnect failed: " + message);
            } catch (IOException ex) {
                System.out.println("Error sending reconnect failed message: " + ex.getMessage());
            }
        }
    }
    
    private void handleNewConnection(Socket socket, ObjectOutputStream out, ObjectInputStream in, String name) {
        System.out.println("Processing new connection from: " + name);
        Player player = new Player(socket, out, in);
        player.playerName = name;
        player.sendMessage(MessageType.string, "Connected to server. Waiting for another player.");
        addClient(player);
    }
    
    private void cleanupFinishedMatches() {
        System.out.println("Cleaning up finished matches");
        synchronized(ongoing) {
            Iterator<Match> iterator = ongoing.iterator();
            while (iterator.hasNext()) {
                Match match = iterator.next();
                // Only remove matches that are truly finished (not running and no connected players)
                if (!match.isRunning && (!match.firstConnected && !match.secondConnected)) {
                    System.out.println("Removing finished match: " + match.firstPlayerName + " vs " + match.secondPlayerName);
                    iterator.remove();
                }
            }
        }
        System.out.println("Remaining matches: " + ongoing.size());
    }
    
    //------------------------------ private function ----------------------------------
    private synchronized void addClient(Player client) {
        System.out.println("Adding client");
        waiting.add(client);
        System.out.println("num of waiting clients: " + waiting.size());
        if (waiting.size() >= 2) {
            Player firstPlayer = waiting.remove(0);
            Player secondPlayer = waiting.remove(0);
            Match match = new Match(firstPlayer, secondPlayer);
            match.firstPlayerName = firstPlayer.playerName;
            match.secondPlayerName = secondPlayer.playerName;
            ongoing.add(match);
            new Thread(match).start();
            System.out.println("Start a new match");
        }
    }
    
    private InetAddress getInetAddress() {
        try {
            Enumeration<NetworkInterface> b = NetworkInterface.getNetworkInterfaces();
            while( b.hasMoreElements()){
                for (InterfaceAddress f : b.nextElement().getInterfaceAddresses())
                    if ( f.getAddress().isSiteLocalAddress()) {
                        return f.getAddress();
                    }
            }
        } catch (SocketException e) {
            System.out.println(e.toString());
            messageLabel.setForeground(Color.red);
            this.messageLabel.setText("Failed to find inet address");
        }
        return null;
    }
    
    private <T> void sendMessageToClient(MessageType type, T data) {
        try {
            sender.writeObject(type);
            sender.writeObject(data);
        } catch (Exception e) {
            System.out.print("Send data Error: ");
            System.out.println(e.toString());
        }
    }
    
    private void log(String log) {
        System.out.println(log);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        startServerButton = new javax.swing.JButton();
        stopServerButton = new javax.swing.JButton();
        messageLabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        portTextField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        ipAddressLabel = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        exitMenuItem = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        jMenu3.setText("jMenu3");

        jMenu4.setText("jMenu4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chess Server");
        setResizable(false);

        startServerButton.setText("Start server");
        startServerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startServerButtonActionPerformed(evt);
            }
        });

        stopServerButton.setText("Stop server");
        stopServerButton.setToolTipText("stop server");
        stopServerButton.setEnabled(false);
        stopServerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopServerButtonActionPerformed(evt);
            }
        });

        messageLabel.setForeground(new java.awt.Color(255, 0, 0));
        messageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        messageLabel.setText("Server: Closed");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jLabel1.setText("Port:");

        portTextField.setText("5555");
        portTextField.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        portTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                portTextFieldDidChange(evt);
            }
        });

        jLabel2.setText("IP:");

        ipAddressLabel.setForeground(new java.awt.Color(0, 0, 255));
        ipAddressLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ipAddressLabel.setText("IP Adress");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(portTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(ipAddressLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(53, 53, 53))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(portTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(ipAddressLabel))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        fileMenu.setText("File");

        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        jMenuBar1.add(fileMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(773, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(messageLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(328, 328, 328)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(stopServerButton)
                    .addComponent(startServerButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(240, 240, 240)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addComponent(messageLabel)
                .addGap(94, 94, 94)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(startServerButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(stopServerButton)
                .addContainerGap(196, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void portTextFieldDidChange(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_portTextFieldDidChange
        if (!portTextField.getText().equals("")) {
            startServerButton.setEnabled(true);
        } else {
            startServerButton.setEnabled(false);
        }
    }//GEN-LAST:event_portTextFieldDidChange

    private void startServerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startServerButtonActionPerformed
        String portString = portTextField.getText();
        try {
            int port = Integer.parseInt(portString);
            this.startServer(port);
            messageLabel.setForeground(Color.green);
            messageLabel.setText("Server started!");
            startServerButton.setEnabled(false);
            stopServerButton.setEnabled(true);
        } catch (Exception e) {
            System.out.println(e.toString());
            messageLabel.setForeground(Color.red);
            messageLabel.setText("Failed to start server with port number: " + portString);
        }
    }//GEN-LAST:event_startServerButtonActionPerformed

    private void stopServerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopServerButtonActionPerformed
        System.out.println("Stoping server");
    }//GEN-LAST:event_stopServerButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Server().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JLabel ipAddressLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel messageLabel;
    private javax.swing.JTextField portTextField;
    private javax.swing.JButton startServerButton;
    private javax.swing.JButton stopServerButton;
    // End of variables declaration//GEN-END:variables
}
