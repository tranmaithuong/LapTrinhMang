/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MangMayTinh.Chess.Connection.Server;

import MangMayTinh.Chess.Model.Chessboard;
import MangMayTinh.Chess.Model.Enum.MessageType;
import MangMayTinh.Chess.Model.Interface.PlayerInterface;
import MangMayTinh.Chess.Model.Move;
import MangMayTinh.Chess.Model.SerializableBoardState;
import MangMayTinh.Chess.Model.Piece;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thinhle
 */
public class Match implements Runnable, PlayerInterface {

    Player firstPlayer;
    Player secondPlayer;
    Chessboard chessboard;
    private int turn = 1; // 1: first player's turn ----- 2: second player's turn
    boolean isRunning = true;
    String firstPlayerName, secondPlayerName;
    boolean firstConnected = true, secondConnected = true;
    List<String> chatHistory = new ArrayList<>();

    public Match(Player firstPlayer, Player sencondPlayer) {
        this.firstPlayer = firstPlayer;
        this.secondPlayer = sencondPlayer;
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        System.out.println("Destructed 1 match");
    }

    @Override
    public void run() {
        this.firstPlayer.setDelegate(this);
        this.secondPlayer.setDelegate(this);
        
        this.firstPlayer.setIsFirstPlayer(true);
        this.secondPlayer.setIsFirstPlayer(false);
        
        // Start player threads - important for communication
        this.firstPlayer.start();
        this.secondPlayer.start();
        
        this.chessboard = new Chessboard();
        this.chessboard.setIsFirstPlayer(true);
        this.chessboard.drawChessboard();
        this.chessboard.setVisible(true);
        
        // Send initial game setup
        this.firstPlayer.sendMessage(MessageType.isFirstPlayer, true);
        this.secondPlayer.sendMessage(MessageType.isFirstPlayer, false);
        
        System.out.println("Match started for players: " + firstPlayerName + " vs " + secondPlayerName);
        
        // Let the match run until ended by both players
        while (this.isRunning) {
            try {
                Thread.sleep(1000);  // Reduce CPU usage with a pause
            } catch (InterruptedException e) {
                break;
            }
        }
        
        System.out.println("Match ended: " + firstPlayerName + " vs " + secondPlayerName);
    }

    private void transform(Move move) {
        Point destination = move.getDestination();
        Point source = move.getSource();
        destination.y = 7 - destination.y;
        destination.x = 7 - destination.x;
        source.y = 7 - source.y;
        source.x = 7 - source.x;
    }
    
    @Override
    public synchronized void setName(String name, boolean isFirstPlayer) {
        if (isFirstPlayer) {
            this.secondPlayer.sendMessage(MessageType.name, name);
            this.firstPlayer.setIsReady(true);
            this.firstPlayerName = name;
        } else {
            this.firstPlayer.sendMessage(MessageType.name, name);
            this.secondPlayer.setIsReady(true);
            this.secondPlayerName = name;
        }
        if (this.firstPlayer.isReady() && this.secondPlayer.isReady()) {
            this.firstPlayer.sendOperation(MessageType.turn);
            this.firstPlayer.sendOperation(MessageType.startGame);
            this.secondPlayer.sendOperation(MessageType.startGame);
        }
    }

    @Override
    public synchronized void didReceiveMessage(String message, boolean isFirstPlayer) {
        chatHistory.add(message);
        if (isFirstPlayer) {
            this.secondPlayer.sendMessage(MessageType.message, message);
        } else {
            this.firstPlayer.sendMessage(MessageType.message, message);
        }
    }

    @Override
    public synchronized void move(Move move, boolean isFirstPlayer) {
        if (isFirstPlayer && turn == 1) {
            this.chessboard.move(move);
            this.transform(move);
            this.secondPlayer.sendMessage(MessageType.move, move);
            turn = 2;
        } else if (turn == 2) {
            this.transform(move);
            this.chessboard.move(move);
            this.firstPlayer.sendMessage(MessageType.move, move);
            turn = 1;
        }
        int checkWinner = this.chessboard.getWinner();
        if (checkWinner == 1) {
            this.firstPlayer.sendMessage(MessageType.result, true);
            this.secondPlayer.sendMessage(MessageType.result, false);
        } else if (checkWinner == 2) {
            this.firstPlayer.sendMessage(MessageType.result, false);
            this.secondPlayer.sendMessage(MessageType.result, true);
        }
    }

    @Override
    public void surrender(boolean isFirstPlayer) {
        if (!isRunning) return;
        System.out.println((isFirstPlayer ? firstPlayerName : secondPlayerName) + " surrendered.");
        
        // Mark the surrendering player as disconnected but still potentially able to reconnect
        if (isFirstPlayer) {
            firstConnected = false;
        } else {
            secondConnected = false;
        }
        
        // Notify the other player about the surrender
        Player opponent = isFirstPlayer ? secondPlayer : firstPlayer;
        if (opponent != null && (isFirstPlayer ? secondConnected : firstConnected)) {
            opponent.sendMessage(MessageType.result, true);  // Opponent wins
            opponent.sendMessage(MessageType.string, 
                (isFirstPlayer ? firstPlayerName : secondPlayerName) + " surrendered but may reconnect later.");
        }
        
        // Send result to surrendering player too
        Player surrenderingPlayer = isFirstPlayer ? firstPlayer : secondPlayer;
        if (surrenderingPlayer != null) {
            surrenderingPlayer.sendMessage(MessageType.result, false);  // Surrendering player loses
        }
        
        // Keep the match running to allow reconnection
        // Only fully end when endGame is called or both players disconnect
    }

    @Override
    public void endGame(boolean isFirstPlayer) {
        if (isFirstPlayer) {
            this.firstPlayer.setIsReady(false);
        } else {
            this.secondPlayer.setIsReady(false);
        }
        
        // Only truly end the game if both players have acknowledged it
        if (!this.firstPlayer.isReady() && !this.secondPlayer.isReady()) {
            this.isRunning = false;
            System.out.println("Match ended between " + firstPlayerName + " and " + secondPlayerName);
            
            // When a game properly ends, notify both players to reset their UI
            resetAllConnections();
        }
    }

    private void resetAllConnections() {
        // Flag both players as disconnected to prevent reconnection to this match
        firstConnected = false;
        secondConnected = false;
        
        System.out.println("Match fully ended - preventing future reconnections");
    }

    @Override
    public synchronized void playerDisconnected(boolean wasFirst, String name) {
        System.out.println("Player disconnected: " + name + ", wasFirst: " + wasFirst);
        
        if (wasFirst) {
            firstConnected = false;
        } else {
            secondConnected = false;
        }
        
        Player other = wasFirst ? secondPlayer : firstPlayer;
        if (other != null && (wasFirst ? secondConnected : firstConnected)) {
            other.sendMessage(MessageType.string, name + " left—waiting for them to rejoin");
        }
        
        // Don't set isRunning=false when players disconnect - keep match alive for reconnection
        System.out.println("Match state after disconnect - firstConnected: " + firstConnected + 
                           ", secondConnected: " + secondConnected + ", isRunning: " + isRunning);
    }

    public synchronized void attemptReconnect(Player p, String name) {
        System.out.println("Attempting reconnect for " + name + 
                          " to match " + firstPlayerName + " vs " + secondPlayerName);
        
        // If the game has ended, don't allow reconnection
        if (!isRunning) {
            p.sendMessage(MessageType.RECONNECT_FAILED, "The game has ended. Please start a new game.");
            return;
        }
                          
        boolean isFirst = name.equals(firstPlayerName) && !firstConnected;
        boolean isSecond = name.equals(secondPlayerName) && !secondConnected;
        
        // Check if both players are disconnected - if so, we'll need to reset the game
        boolean bothDisconnected = !firstConnected && !secondConnected;
        
        if (!isFirst && !isSecond) {
            System.out.println("Cannot rejoin - player name mismatch or slot already filled");
            System.out.println("Details: name=" + name + ", firstPlayerName=" + firstPlayerName + 
                             ", firstConnected=" + firstConnected + 
                             ", secondPlayerName=" + secondPlayerName + 
                             ", secondConnected=" + secondConnected);
            p.sendMessage(MessageType.RECONNECT_FAILED, "Cannot rejoin - your slot is already taken or game ended");
            return;
        }
        
        // If we're here, the player can reconnect
        if (isFirst) {
            firstPlayer = p;
            firstConnected = true;
            p.setIsFirstPlayer(true);
            p.setIsReady(true); // Make sure player is set to ready
            System.out.println(name + " reconnected as first player");
        } else {
            secondPlayer = p;
            secondConnected = true;
            p.setIsFirstPlayer(false);
            p.setIsReady(true); // Make sure player is set to ready
            System.out.println(name + " reconnected as second player");
        }
        
        p.setDelegate(this);
        
        try {
            // Start with successful reconnection message
            p.sendMessage(MessageType.RECONNECT_SUCCESSFUL, "Welcome back to the game!");
            
            // If both players were disconnected, reset the game instead of restoring state
            if (bothDisconnected) {
                resetGameForBothPlayers();
                p.sendOperation(MessageType.startGame);
                return;
            }
            
            // Normal reconnection flow with state sync
            p.sendOperation(MessageType.GAME_STATE_SYNC_START);
            
            // Send player identity information 
            p.sendMessage(MessageType.isFirstPlayer, isFirst);
            p.sendMessage(MessageType.name, isFirst ? secondPlayerName : firstPlayerName);
            
            // Create board state for the specific player's perspective
            List<SerializableBoardState.SerializablePiece> pieces = new ArrayList<>();
            for (Piece piece : chessboard.firstPlayerPieces) {
                if (piece.isAlive()) {
                    Point position = new Point(piece.getNowPosition());
                    
                    // Transform position for second player's view if needed
                    if (!isFirst) {
                        position.x = 7 - position.x;
                        position.y = 7 - position.y;
                    }
                    
                    pieces.add(new SerializableBoardState.SerializablePiece(
                        piece.getClass().getSimpleName(), 
                        position,
                        true
                    ));
                }
            }
            
            for (Piece piece : chessboard.secondPlayerPieces) {
                if (piece.isAlive()) {
                    Point position = new Point(piece.getNowPosition());
                    
                    // Transform position for second player's view if needed
                    if (!isFirst) {
                        position.x = 7 - position.x;
                        position.y = 7 - position.y;
                    }
                    
                    pieces.add(new SerializableBoardState.SerializablePiece(
                        piece.getClass().getSimpleName(), 
                        position,
                        false
                    ));
                }
            }
            
            // Create board state with the correct pieces and player perspective
            SerializableBoardState boardState = new SerializableBoardState(pieces, turn, isFirst);
            System.out.println("Sending board state with " + boardState.pieces.size() + " pieces to " + 
                              (isFirst ? "first" : "second") + " player");
            
            // Send game state data
            p.sendMessage(MessageType.BOARD_STATE, boardState);
            p.sendMessage(MessageType.CHAT_HISTORY, chatHistory);
            
            // Set turn information
            if ((isFirst && turn == 1) || (!isFirst && turn == 2)) {
                p.sendOperation(MessageType.turn);
            }
            
            // End synchronization sequence
            p.sendOperation(MessageType.GAME_STATE_SYNC_END);
            
            // Start the player thread
            p.start();
            
            // Notify the other player
            Player other = isFirst ? secondPlayer : firstPlayer;
            if (other != null && (isFirst ? secondConnected : firstConnected)) {
                other.sendMessage(MessageType.string, name + " has reconnected to the game!");
            }
            
            System.out.println("Reconnection complete for " + name);
        } catch (Exception e) {
            System.out.println("Error during reconnection for " + name + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    // New method to reset the game when both players were disconnected
    private void resetGameForBothPlayers() {
        System.out.println("Both players were disconnected - resetting game for fresh start");
        
        // Create a new chessboard with initial state
        this.chessboard = new Chessboard();
        this.chessboard.setIsFirstPlayer(true);
        this.chessboard.drawChessboard();
        
        // Reset turn to first player
        turn = 1;
        
        // Clear chat history
        chatHistory.clear();
        
        // Reset first player
        firstPlayer.setIsFirstPlayer(true);
        firstPlayer.sendMessage(MessageType.RECONNECT_SUCCESSFUL, "Game reset - both players were disconnected");
        firstPlayer.sendMessage(MessageType.isFirstPlayer, true); 
        firstPlayer.sendMessage(MessageType.name, secondPlayerName);
        firstPlayer.sendOperation(MessageType.turn);
        firstPlayer.sendOperation(MessageType.startGame);
        
        // Reset second player if connected
        if (secondConnected) {
            secondPlayer.setIsFirstPlayer(false);
            secondPlayer.sendMessage(MessageType.RECONNECT_SUCCESSFUL, "Game reset - both players were disconnected");
            secondPlayer.sendMessage(MessageType.isFirstPlayer, false);
            secondPlayer.sendMessage(MessageType.name, firstPlayerName);
            secondPlayer.sendOperation(MessageType.startGame);
        }
        
        // Let players know the game is reset
        System.out.println("Game reset complete, notified connected players");
    }

    // New helper method to check if match should be cleaned up
    public boolean shouldBeRemoved() {
        return !isRunning && (!firstConnected && !secondConnected);
    }
}
